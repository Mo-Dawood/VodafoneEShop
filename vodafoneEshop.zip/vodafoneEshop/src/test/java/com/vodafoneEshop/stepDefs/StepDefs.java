package com.vodafoneEshop.stepDefs;

import com.vodafoneEshop.Factory.DriverFactory;
import com.vodafoneEshop.pages.HomePage;
import com.vodafoneEshop.pages.ItemPage;
import com.vodafoneEshop.pages.LoginPage;
import com.vodafoneEshop.utils.ConfigUtils;
import com.vodafoneEshopTests.base.TestBase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.testng.Assert;

public class StepDefs extends TestBase {


    HomePage homePage;
    ItemPage itemPage;
    LoginPage loginPage;

    public StepDefs() {
        
        homePage = new HomePage(driver);
        itemPage = new ItemPage(driver);
        loginPage = new LoginPage(driver);
    }

   @Given("user open vodafone e-shop website")
   public void userVodafoneEshopWebsite(){
       homePage.loadWebSite();
   }
    @And("click on accept all cookies button")
    public void userClickOnAcceptAllCookiesButton() throws InterruptedException {
        homePage.acceptCookies();
    }
    @And("click on log in icon to log in")
    public void clickOnLogInIcon(){
        homePage.clickOnLogInIcon();
    }
    @And("enter his mobile number in username field")
    public void enterHisMobileNumberInUserNameField(){
        loginPage.enterMobileNumber(ConfigUtils.getInstance().getUserName());
    }
    @And("enter his password in password field")
    public void enterPasswordInPasswordField(){
        loginPage.enterPassword(ConfigUtils.getInstance().getPassword());
    }
    @And("click on go to my account button")
    public void clickOnGoToMyAccountButton() throws InterruptedException {
        loginPage.clickOnGoToMyAccountButton();
    }
    @And("select the first item")
    public void selectTheFirstItem() throws InterruptedException {
        homePage.selectFirstItem();
    }
    @And("add the item to the cart")
    public void addTheItemToTheCart() throws InterruptedException {
        itemPage.addItemToTheCart();
    }
    @And("return to the home page")
    public void returnToTheHomePage(){
        itemPage.clickOnVodafoneEshopIcon();
    }
    @And("select the second item")
    public void selectTheSecondItem() throws InterruptedException {
        homePage.selectSecondItem();
    }
    @And("select the third item from search bar")
    public void selectTheThirdItemFromSearchBar() throws InterruptedException {
        homePage.selectThirdItemFromSearchBar();
    }
    @Then("validate that items number in cart icon should equal to transactions amount")
    public void validateThatItemsNumberInCartIconShouldEqualToTransactionsAmount(){
        String actualResult = homePage.getCartIconNumber();
        Assert.assertEquals(actualResult , "");
    }

}
