package com.vodafoneEshopTests.testCases;

import com.vodafoneEshop.pages.HomePage;
import com.vodafoneEshop.utils.ConfigUtils;
import com.vodafoneEshopTests.base.TestBase;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ItemTest extends TestBase {

    @Test
    public void selectFirstItem() throws InterruptedException {
        HomePage homePage = new HomePage(driver);

        String itemsNumber = homePage
                .loadWebSite()
                .acceptCookies()
                .clickOnLogInIcon()
                .enterMobileNumber(ConfigUtils.getInstance().getUserName())
                .enterPassword(ConfigUtils.getInstance().getPassword())
                .clickOnGoToMyAccountButton()
                .selectFirstItem()
                .addItemToTheCart()
                .clickOnVodafoneEshopIcon()
                .selectSecondItem()
                .addItemToTheCart()
                .clickOnVodafoneEshopIcon()
                .selectThirdItemFromSearchBar()
                .addItemToTheCart()
                .clickOnVodafoneEshopIcon()
                .getCartIconNumber();

        Assert.assertEquals(itemsNumber, "");


    }
}
