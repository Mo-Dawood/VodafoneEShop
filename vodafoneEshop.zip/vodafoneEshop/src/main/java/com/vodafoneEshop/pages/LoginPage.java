package com.vodafoneEshop.pages;

import com.vodafoneEshop.Base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;

public class LoginPage extends BasePage {
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    private final By mobileNumberField = By.xpath("//input[@id='username']");
    private final By passwordField = By.xpath("//input[@id='password']");
    private final By goToMyAccountButton = By.xpath("//input[@id='submitBtn']");

    public LoginPage enterMobileNumber(String number) {
        WebElement mobileNumber = findElement(mobileNumberField);
        mobileNumber.sendKeys(number);
        return this;
    }

    public LoginPage enterPassword(String password) {
        WebElement mobileNumber = findElement(passwordField);
        mobileNumber.sendKeys(password);
        return this;
    }

    public HomePage clickOnGoToMyAccountButton() throws InterruptedException {
        WebElement button = findElement(goToMyAccountButton);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOf(button));
        wait.until(ExpectedConditions.elementToBeClickable(button));
        button.click();
        return new HomePage(driver);
    }
}
