package com.vodafoneEshop.pages;

import com.vodafoneEshop.Base.BasePage;
import com.vodafoneEshop.utils.ConfigUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {

    private final By cookiesLocator = By.id("onetrust-accept-btn-handler");
    private final By searchBarLocator = By.xpath("//input[@id='searchInput']");
    private final By firstItem = By.xpath("//p[contains(text(),'Apple Watch Series 8 GPS 41mm')]");
    private final By secondItem = By.xpath("//p[contains(text(),'Apple Watch Series 9 GPS 45mm')]");
    private final By logInIcon = By.xpath("//body/vf-root[1]/main[1]/section[1]/vf-nav-bar[1]/nav[1]/div[1]/vf-user-profile[1]/div[1]/button[1]/img[1]");
    private final By cartIcon = By.xpath("//body/vf-root[1]/main[1]/section[1]/vf-nav-bar[1]/nav[1]/div[1]/div[3]/vf-cart[1]/div[1]/button[1]/img[1]");
    private final By thirdItem = By.xpath("//div[@class='search-results desktop-search-results']//div//p[contains(text(),'Marshall WILLEN Portable Speaker')]");


    public HomePage(WebDriver driver) {
        super(driver);
    }

    public HomePage loadWebSite() {
        driver.get(ConfigUtils.getInstance().getBaseUrl());
        return this;
    }

    public HomePage acceptCookies() throws InterruptedException {
        Thread.sleep(2000);

        WebElement cookies = findElement(cookiesLocator);
        cookies.click();
        return this;
    }

    public LoginPage clickOnLogInIcon() {
        WebElement icon = findElement(logInIcon);
        icon.click();
        return new LoginPage(driver);
    }

    public ItemPage selectFirstItem() throws InterruptedException {

        Thread.sleep(2000);
        WebElement item = findElement(firstItem);
        Actions actions = new Actions(driver);

        actions.moveToElement(item).perform();

        wait.until(ExpectedConditions.visibilityOf(item));
        wait.until(ExpectedConditions.elementToBeClickable(item));

        item.click();

        return new ItemPage(driver);
    }
    public ItemPage selectSecondItem() throws InterruptedException {

        Thread.sleep(2000);
        WebElement item = findElement(secondItem);
        Actions actions = new Actions(driver);

        actions.moveToElement(item).perform();

        wait.until(ExpectedConditions.visibilityOf(item));
        wait.until(ExpectedConditions.elementToBeClickable(item));

        item.click();

        return new ItemPage(driver);
    }

    public ItemPage selectThirdItemFromSearchBar() throws InterruptedException {
        WebElement searchBar = findElement(searchBarLocator);
        searchBar.click();
        searchBar.sendKeys("speaker");
        Thread.sleep(500);
        WebElement thirdProduct = findElement(thirdItem);
        wait.until(ExpectedConditions.visibilityOf(thirdProduct));
        thirdProduct.click();
        return new ItemPage(driver);
    }
    public String getCartIconNumber() {
        WebElement cart = findElement(cartIcon);
        return cart.getText();
    }
}