package com.vodafoneEshop.pages;

import com.vodafoneEshop.Base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ItemPage extends BasePage {
    public ItemPage(WebDriver driver) {
        super(driver);
    }

    private final By addToCartButton = By.xpath("//button[contains(text(),'Add To Cart')]");
    private final By vodafoneEshopLogo = By.xpath("//p[contains(text(),'Vodafone E-shop')]");


    public ItemPage addItemToTheCart() throws InterruptedException {

        Thread.sleep(2000);
        WebElement addToCart = findElement(addToCartButton);
        wait.until(ExpectedConditions.visibilityOf(addToCart));
        wait.until(ExpectedConditions.elementToBeClickable(addToCart));
        addToCart.click();
        return this;
    }

    public HomePage clickOnVodafoneEshopIcon() {
        WebElement vodafoneEshop = findElement(vodafoneEshopLogo);
        vodafoneEshop.click();
        return new HomePage(driver);
    }

}
