package com.vodafoneEshop.pages;

import com.vodafoneEshop.Base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CartPage extends BasePage {
    public CartPage(WebDriver driver) {
        super(driver);
    }

    private final By clearCartIcon = By.xpath("//body/vf-root[1]/main[1]/section[2]/vf-my-cart[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[3]/p[1]/img[1]");


    public HomePage clearCart() {
        WebElement clearCartButton = findElement(clearCartIcon);
        clearCartButton.click();
        return new HomePage(driver);
    }
}
